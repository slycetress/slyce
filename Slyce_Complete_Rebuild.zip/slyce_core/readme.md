# Slyce Core
Recursive logic and memory.